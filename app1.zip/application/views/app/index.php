index ... loaded
<?php 
 echo $data;
?>