<?php 

class App extends SUB_Controller{



  
  function index(){
   
     echo 'App loaded ... ';

     $out = array();
     $input = array('data'=>'12444');
     $input['data'] = 141;

     call_usecase('foo.foo_test',$input,$out);

     print_r($out);


     call_route(array('foo-user','method','arg1','arg2'));

  }




}

