<?php

class Rt_app_index extends CI_Model implements iRoute{
 
   private $params = array();
   private $uri = array();
   private $output = array();

   
   function get_uri($uri){
     $this->uri = $uri;
     if (!isset($this->uri[0])){
       $this->uri[0] = 4;
     }
   }

   function get_params($params){
    $this->params = $params;
   }

   function exec(){
     
     $this->uri[0] = $this->uri[0] * 3;
     $input = array('data'=>'123434534');
     $output = array();
     call_usecase('foo.foo_test',$input,$this->output);
     $this->output['data_out'] = $this->uri[0];

   }

   function get_output(){
     return $this->output;
   }

   function get_template(){
     return 'app/index';
   }


}

