<?php 

class Foo_test extends CI_Model implements IUseCase{
  
  private $in = array();
  private $out = array('message'=>'out ok.');

  function get_input($input){
    $this->in = $input;
    if (!isset($this->in['data'])){
      throw new Exception("data param required from the input!", 1);
    }
  }

  function exec(){

    // throw new Exception("Error Processing Request", 1);

    $this->out['data'] = $this->in['data'] + 10;

  }

  function get_output(){
    return $this->out;
  }

     

}