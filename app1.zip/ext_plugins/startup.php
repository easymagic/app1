<?php 
 // $ext_plugin_path = 'ext_plugins/';
 // echo 'SU.';

function array_equal($a, $b) {
    return (
         is_array($a) 
         && is_array($b) 
         && count($a) == count($b) 
         && array_diff($a, $b) === array_diff($b, $a)
    );
}




function listeners($tag,$cb=''){

  static $listeners_arr = array();

  if (is_array($tag)){
    $tag = implode('__evt__', $tag);
  }

  if (!isset($listeners_arr[$tag])){
    $listeners_arr[$tag] = array();
  }

  if (!empty($cb))$listeners_arr[$tag][] = $cb;

  if ($cb == '__unset__'){
    unset($listeners_arr[$tag]);
  }


  if (isset($listeners_arr[$tag])){
    return $listeners_arr[$tag];
  }else{
    return array();
  }
   

}




 function scan_plugins(){
  
  // global $ext_plugin_path;
  $path = 'ext_plugins/plugins';
  $dir = scandir($path);
  $dir = array_diff($dir, array('.','..'));
  

  foreach ($dir as $k=>$v){

      $file = 'ext_plugins/plugins/' . $v . '/' . $v . '_plugin.php';
      
      if (file_exists($file)){
        require_once($file);
      }

  }
 }

 function run_listeners($hook,&$args){
     $listeners_ = listeners($hook);

     foreach ($listeners_ as $k=>$fn){
       if (function_exists($fn) || is_array($fn)){

        $args = call_user_func_array($fn, $args);
        
             $args = array($args);
        
       }
     }
 }
 
 function __filter(){
   $args = func_get_args();
   
   if (count($args) > 0){

     $hook = array_shift($args);

     run_listeners($hook,$args);

   }

   if (isset($args[0])){
    return $args[0];
   }else{
    return '';
   }

   

 }


 function __action(){
  return call_user_func_array('__filter', func_get_args());
 }


 function add_listener($tag,$cb){
  listeners($tag,$cb);
 }

 function remove_listener($tag){
   listeners($tag,'__unset__');
 }


 function start_buffer(){
  ob_start();
 }

 function get_buffer(){
  $r = ob_get_contents();
  ob_end_clean();
  return $r;
 }


 function response($k='',$v=''){
   
   static $resp = array();

   if (empty($k) && empty($v)){
     return $resp;
   }

   session($k,$v);
   
   if (is_array($v) || is_numeric($v) || !empty($v)){
     $resp[$k] = $v;
   }

   if ($v == '__unset__'){
    unset($resp[$k]);
   }

   if (isset($resp[$k])){
    return $resp[$k];
   }else{
    return '';
   } 

 }


 function env($k,$v=''){
   
   static $resp = array();

   if (empty($k) && empty($v)){
     return $resp;
   }
   
   if (is_array($v) || is_numeric($v) || !empty($v)){
     $resp[$k] = $v;
   }

   if ($v == '__unset__'){
    unset($resp[$k]);
   }

   if (isset($resp[$k])){
    return $resp[$k];
   }else{
    return '';
   } 

 }


 function request($k='',$v=''){
   
   static $resp;

   if (!isset($resp)){
    $resp = &$_REQUEST;
   }
   
   if (empty($k) && empty($v)){
     return $resp;
   }

   if (is_array($v) || is_numeric($v) || !empty($v)){
     $resp[$k] = $v;
   }

   if ($v == '__unset__'){
    unset($resp[$k]);
   }

   if (isset($resp[$k])){
    return $resp[$k];
   }else{
    return '';
   } 

 }

 function post($k,$v=''){
   static $resp;

   if (!isset($resp)){
    $resp = &$_POST;
   }

   if (empty($k) && empty($v)){
     return $resp;
   }
   
   if (is_array($v) || is_numeric($v) || !empty($v)){
     $resp[$k] = $v;
   }


   if ($v == '__unset__'){
    unset($resp[$k]);
   }


   if (isset($resp[$k])){
    return $resp[$k];
   }else{
    return '';
   } 
 }

 function session($k='',$v=''){
   static $resp;

   if (!isset($resp)){
    // print_r($_SESSION);
    $resp = &$_SESSION;
   }
   
   if (empty($k) && empty($v)){
     return $resp;
   }

   if (is_array($v) || is_numeric($v) || !empty($v)){
     $resp[$k] = $v;
   }

   if ($v == '__unset__'){
    unset($resp[$k]);
   }

   if (isset($resp[$k])){
    return $resp[$k];
   }else{
    return '';
   }

 }

 function history($v=''){
   // echo $v;
   return session('__history__',$v);
 }

 function save_history(){
  history(env('__history__'));
 }

 function log_error($msg){
   response('message',$msg);
   response('error','1');
 }

 function log_success($msg){
   response('message',$msg);
   response('error','0');
 }

 function log_reset(){
   response('message','__unset__');
   response('error','__unset__');  
 }

 function redirect($route){
  header('location:' . BASE_URL . $route);
  exit();
 }

 function controller($obj=null){
   static $ref = null;

   if ($ref == null && $obj != null){
     $ref = $obj;
   }

   return $ref;
 }

 function _db(){
   return controller()->db;
 }

 function init_usecases($dir_){
   $dir = scandir('ext_plugins/plugins/' . $dir_ . '/usecases');
   $dir = array_diff($dir, array('.','..'));

   foreach ($dir as $k=>$v){
    require_once("ext_plugins/plugins/$dir_/usecases/$v");
   }  
 }


 //interface definition for usecase
 interface iUseCase{
   
   function get_input($_input_);

   function exec();

   function get_output();

 }

 //interface definition for routes
 interface iRoute{

   function get_uri($uri);
   function get_params($params);
   function exec();
   function get_output();
   function get_template();

 }


 function call_usecase($uc,$input,&$output){
   $salt = 'model_usecase_' . uniqid();
   try {
     $uc = explode('.', $uc); 
     array_unshift($uc, 'usecases'); //inject the usecases namespace to it.
     $uc = implode('/', $uc);

     controller()->load->model($uc,$salt);

     controller()->$salt->get_input($input);
     controller()->$salt->exec();
     $output = controller()->$salt->get_output();
     if (isset($output['message'])){
      log_success($output['message']);
     }else{
      log_success('ok');
     }
     $output['error'] = false;
   } catch (Exception $e) {
     log_error($e->getMessage());
     $output['message'] = $e->getMessage();
     $output['error'] = true;
   }
 }

 function call_route($args=array()){

  // print_r($args);

   $route_shortcut = get_route_shortcut();
   
   $salt = 'model_route_' . uniqid();

   $model = array_shift($args);
   $method = array_shift($args);

   if (empty($model)){
     $model = $route_shortcut['default_route_model'];
   }

   if (is_numeric($method)){
     $args[] = $method;
     $method = 'index';
   }

   if (isset($route_shortcut[$model]) ){

     // echo $model;

    // print_r($args);
     
     $pick = $route_shortcut[$model];
     $pick = explode('/', $pick);
     $pick = array_reverse($pick);

     foreach ($pick as $k=>$v){
       array_unshift($args, $v);
     }

     // print_r($args);

     $model = array_shift($args);
     $method = array_shift($args);
    
   }

   if (empty($method)){
     $method = 'index';
   }


   // echo $model;

   $package = $model;
   $cls = 'rt_' . $package . '_' . $method;
   $rsc = 'routes/' . $package . '/' . $cls;
   controller()->load->model($rsc,$salt);

   controller()->$salt->get_uri($args);

   controller()->$salt->get_params($_GET);

   controller()->$salt->exec();

   $data = controller()->$salt->get_output();

   $view = controller()->$salt->get_template();

   if (!empty($view)){
    return controller()->load->view($view,$data,true);
   }else{
    return $data; //means this data should be a string.
   }

   // echo $model;
   // print_r($args);
   // echo $method;

 }

 function get_route_shortcut(){
  $routes = array();
  include('routes.php');
  return $routes;
 }

 

 scan_plugins();

