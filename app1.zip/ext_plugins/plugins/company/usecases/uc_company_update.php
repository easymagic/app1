<?php 

function uc_company_update($id=''){
  $post = request('company');	
  __action('entity_where','id',$id);
  __action('entity_update','company',$post);
  log_success('Company Updated.');
}
add_listener('uc_company_update','uc_company_update');