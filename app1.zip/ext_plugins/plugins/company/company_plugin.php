<?php 

//company plugin
init_usecases('company');



function company_add_entity($type=''){

	start_buffer();
    
    include('template/company_add.php');

	return __filter('nav_admin_panel',get_buffer());
 
}
add_listener('nav_company_add_entity','company_add_entity');


function company_add_hmo(){
 save_history();	
 return __action('nav_company_add_entity','hmo');
}
add_listener('nav_company_add_hmo','company_add_hmo');


function company_add_hospital(){
 save_history();
 return __action('nav_company_add_entity','hospital');
}
add_listener('nav_company_add_hospital','company_add_hospital');


function company_edit($id=''){

	save_history();
    
    $account = session('admin_account'); 
    $company_id = $account->company_id;

    __action('entity_where',array(
    	 "created_by"=>$company_id,
    	 "id"=>$id
    	));

    $item = __action('entity_get','company');

    if (isset($item[0]))$item = $item[0];

	start_buffer();
    
    include('template/company_edit.php');

	return __filter('nav_admin_panel',get_buffer());
 
}
add_listener('nav_company_edit','company_edit');


function company_list_entity($type=''){


    // $account = session('admin_account'); 
    // $company_id = $account->company_id;

    // __action('entity_where',array(
    // 	 "created_by"=>$company_id,
    // 	 "type"=>$type
    // 	));

    // $item = __action('entity_get','company');

    __action('launch_usecase',array("company","list",$type));
	$item = response('data');

	start_buffer();


    
    include('template/company_list.php');

	return __filter('nav_admin_panel',get_buffer());

}
add_listener('nav_company_list_entity','company_list_entity');


function company_hmo(){
 return __action('nav_company_list_entity','hmo');
}
add_listener('nav_company_hmo','company_hmo');


function company_hospital(){
 return __action('nav_company_list_entity','hospital');
}
add_listener('nav_company_hospital','company_hospital');


