<?php 

 function uc_talent_list(){
  $resp = __action('entity_get','talent');
  response('data',$resp);
 }
 add_listener('uc_talent_list','uc_talent_list');



 function uc_talent_register(){
  //use super-keys
  //surname,email,phone,bvn
  $post_data = request('post_data');
  $surname = $post_data['surname']; 	
  $email = $post_data['email'];
  $phone = $post_data['phone'];
  $bvn = $post_data['bvn'];

  $post_data['verified'] = 1;
  $post_data['date_created'] = date('Y-m-d h:i:s');

  $criteria = array();
  // $criteria['surname'] = $surname;
  $criteria['email'] = $email;
  $criteria['phone'] = $phone;
  $criteria['bvn'] = $bvn;

  $resp = __action('entity_get_where','talent',$criteria); 

  if (count($resp) > 0){
   log_error('Registration previously made!');
  }else{
    __action('entity_create','talent',$post_data);
    log_success('Registration confirmed');
  }

 }
 add_listener('uc_talent_register','uc_talent_register');


 function uc_talent_spam_count($talent_id){
  $resp = __action('entity_get_where','talent',array("id"=>$talent_id));
  response('spam_count',$resp[0]->spam);
  if ($resp[0]->spam > 0){
   log_error('This individual has been marked as spam to a count of ' . $resp[0]->spam);
  }else{
   log_success('This individual is ok.');
  }
 }
 add_listener('uc_talent_spam_count','uc_talent_spam_count');


function inc_spam_count($talent_id){
  
  $resp = __action('entity_get_where','talent',array("id"=>$talent_id));
  $resp = $resp[0];
  $spam = $resp->spam;
  ++$spam;
  __action('entity_where','id',$talent_id);
  __action('entity_update','talent',array("spam"=>$spam));
  return $spam;
}
add_listener('inc_spam_count','inc_spam_count');


 function uc_talent_mark_as_spam($talent_id,$consumer_id){
   
   $res = __action('entity_get_where','spam',array("talent_id"=>$talent_id,"consumer_id"=>$consumer_id));
   if (count($res) > 0){
     //do nothing
    log_error('Already marked as spam!');
   }else{
    $spam_count = __action('inc_spam_count',$talent_id);
    __action('entity_create','spam',array("talent_id"=>$talent_id,"consumer_id"=>$consumer_id,"date_created"=>date('Y-m-d h:i:s')));
    log_success('Current talent has been marked as spam with count of ' . $spam_count);
   }

 }
 add_listener('uc_talent_mark_as_spam','uc_talent_mark_as_spam');



function uc_talent_analyse($key='bvn'){

  $post_data = request('post_data'); 
 
 __action('entity_where',$key,$post_data[$key]);
 $resp = __action('entity_get','talent');
 response('data',$resp);
 log_success('Talent analysed...');

}
add_listener('uc_talent_analyse','uc_talent_analyse');