<div class="col-xs-12">
	<h3>Talents</h3>
</div>

<?php 
 // print_r($_SERVER);
?>

<div class="col-xs-12" align="right">
<!-- 	<a href="<?php echo base_url(); ?>admin/add_user" class="btn btn-primary"> + Add User</a>
 --></div>

<div class="col-xs-12">
	<?php 
      __filter('log_message');
	?>
</div>


<div class="col-xs-12">
	<table class="table">
		<tr>
			<th>
				Surname
			</th>
			<th>
				First Name
			</th>
         <th>
            Last Name
         </th>
         <th>
            Gender
         </th>         
         <th>
            Phone
         </th>
         <th>
            E-mail
         </th>
         <th>
           BVN
         </th>
         <th>
           Account-Number
         </th>
         <th>
           Gender
         </th>
		</tr>
		<?php 
         foreach ($result['record'] as $k=>$v){

         	?>
            
     <tr>

      <td>
        <?php echo $v->surname; ?>
      </td>
      <td>
        <?php echo $v->first_name; ?>
      </td>
         <td>
            <?php echo $v->last_name; ?>
         </td>
         <td>
            <?php echo $v->gender; ?>
         </td>         
         <td>
            <?php echo $v->phone; ?>
         </td>
         <td>
            <?php echo $v->email; ?>
         </td>
         <td>
           <?php echo $v->bvn; ?>
         </td>
         <td>
           <?php echo $v->account_number; ?>
         </td>
         <td>
           <?php echo $v->gender; ?>
         </td>


            	<td>

                  <a href="" class="btn btn-info">Detail</a>

            	</td>

            </tr>

         	<?php 

         }
		?>
	</table>
</div>

<div class="col-xs-12">
   <?php 
     if (isset($result['pagination']['firstpage'])){
   ?>
   <a href="?page=<?php echo $result['pagination']['firstpage']; ?>" class="btn btn-default">First</a>
   <?php   
     }
   ?>

   <?php 
     if (isset($result['pagination']['prevpage'])){
   ?>
   <a href="?page=<?php echo $result['pagination']['prevpage']; ?>" class="btn btn-default">Prev</a>
   <?php   
     }
   ?>



   <?php 
     if (isset($result['pagination']['nextpage'])){
   ?>
   <a href="?page=<?php echo $result['pagination']['nextpage']; ?>" class="btn btn-default">Next</a>
   <?php   
     }
   ?>


      <?php 
     if (isset($result['pagination']['lastpage'])){
   ?>
   <a href="?page=<?php echo $result['pagination']['lastpage']; ?>" class="btn btn-default">Last</a>
   <?php   
     }
   ?>   
</div>
