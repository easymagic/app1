<?php 

require_once('usecases.php');


function nav_talent_view(){
 
 start_buffer();

 $result = __action('record_management',array(
  "table"=>"talent",
  "limit"=>30,
  "sort"=>array("id","desc"),
  "criteria"=>array()
 ));

 include('template/list.php');

 return __action('nav_admin_panel',get_buffer());

}
add_listener('nav_talent_view','nav_talent_view');


function talent_map_field($talent_id,$field){
  
  $resp = __action('entity_get_where','talent',array("id"=>$talent_id));
  return $resp[0]->$field;

}
add_listener('talent_map_field','talent_map_field');
