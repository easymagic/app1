
	

	<div class="col-xs-12">
		<label>
			E-mail
		</label>
	</div>
	<div class="col-xs-12">
		<input class="form-control" type="text" name="user[email]" value="<?php echo $data->email; ?>" />
	</div>


	<div class="col-xs-12">
		<label>
			Phone
		</label>
	</div>
	<div class="col-xs-12">
		<input class="form-control" type="number" name="user[phone]" value="<?php echo $data->phone; ?>"/>
	</div>


	<div class="col-xs-12">
		<label>
			Address
		</label>
	</div>
	<div class="col-xs-12">
		<input class="form-control" type="text" name="user[address]" value="<?php echo $data->address; ?>"/>
	</div>






