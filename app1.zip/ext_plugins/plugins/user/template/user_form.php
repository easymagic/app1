	
	<div class="col-xs-12">
		<label>
			Type
		</label>
	</div>
	<div class="col-xs-12 col-md-5">
		<?php echo __filter('user_compute_type',$type); ?>
	</div>



	<div class="col-xs-12">
		<label>
			E-mail
		</label>
	</div>
	<div class="col-xs-12">
		<input type="text" name="user[email]" required="" class="form-control"/>
	</div>


	<div class="col-xs-12">
		<label>
			Phone
		</label>
	</div>
	<div class="col-xs-12">
		<input type="number" name="user[phone]" class="form-control"/>
	</div>


	<div class="col-xs-12">
		<label>
			Address
		</label>
	</div>
	<div class="col-xs-12">
		<input type="text" name="user[address]" class="form-control"/>
	</div>





	<div class="col-xs-12">
		<label>
			Password
		</label>
	</div>
	<div class="col-xs-12">
		<input type="password" name="user[password]" class="form-control"/>
	</div>


	<div class="col-xs-12">
		<label>
			Confirm Password
		</label>
	</div>
	<div class="col-xs-12">
		<input type="password" name="password2" class="form-control" />
	</div>




