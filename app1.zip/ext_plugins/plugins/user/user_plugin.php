<?php 

include("user_usecase.php");



function user_update_success($msg=''){
 $post_data = request('user');
 if (count($post_data) == 1 && isset($post_data['status'])){
   if ($post_data['status'] == 1){
     return 'Selected account activated.';
   }else{
     return 'Selected account deactivated.';
   }
 }else{
   return $msg;
 }
}
add_listener('user_update_success','user_update_success');

function user_create_error(){
 return response('message');
}
add_listener('user_create_error','user_create_error');




 function user_menu_top($menu){
   $r = array();
   // $role = session('admin_account')->role;

   // if ($role == 'admin'){
   //   $r = array_merge($r,array(array("Admin Users","admin/users")));     
   // }

   $r = array_merge($r,array(array("Admin Acct.","user/profile","fa fa-user")));
   $r = array_merge($r,array(array("Change Pwd.","admin/change_password","fa fa-lock")));

   // print_r($r);
   return $r;
 }
 add_listener('admin_menu_top','user_menu_top');

 function user_profile(){
   return __action('nav_admin_edit', session('admin_account')->id);
 }
 add_listener('nav_user_profile','user_profile');




 function user_compute_type($type,$value=''){
  start_buffer();
  include('template/user_type.php');
  return get_buffer();
 }
 add_listener('user_compute_type','user_compute_type');


 function user_before_create($flag){
  
  $user_id = session('admin_account')->id;
  $post_data = request('user');
  $post_data['date_created'] = date('Y-m-d h:i:s');
  $post_data['parent_id'] = $user_id;
  $password2 = request('password2');

  $email = $post_data['email'];
  $resp = __action('entity_get_where','user',array("email"=>$email));
  if (count($resp) > 0){
  	response('message','An account with this email already exists!');
    return true;
  }else{ 
  	if ($post_data['password'] == $password2 && strlen($post_data['password']) > 0){
  		// unset($post_data['confirm_password']); //garbage this out.
  		request('user',$post_data);
       return $flag;  
  	}else{
  	   response('message','Passwords don\'t match!');
       return true; 
  	}
    
  }
 }
 add_listener('user_before_create','user_before_create');



 function nav_user_reset_password($user_id=''){
  save_history();	
  start_buffer();
  include('template/reset_password.php');
  return __action('nav_admin_panel',get_buffer());
 }
 add_listener('nav_user_reset_password','nav_user_reset_password');





function user_list($tag,$data,$config){
 start_buffer();
 include('template/user_list.php'); 
 return get_buffer();
}
add_listener('user_table','user_list');

function user_filter_view($tag,$config){
 return '';
}
add_listener('user_filter_view','user_filter_view');


function user_form($tag,$data,$config){

	start_buffer();
	$type = session('admin_account')->type;

  // print_r($config);

  if (!isset($config['arg1'])){
    $config['arg1'] = $type;
  }
  
  if (empty($data)){
    $user_type = $config['arg1'];
  }else{
    $user_type = $data->type;
  }
  

  $file1 = 'template/' . $user_type . '/' . $user_type . '_form.php';
  $file2 = 'template/' . $user_type . '/' . $user_type . '_form_data.php';

	if (empty($data)){
     include($file1); 
	}else{
     include($file2); 
	}
	return get_buffer();
 
}
add_listener('user_form','user_form');


function user_back_link($tag,$data,$config){
 $user_id = session('admin_account')->id;

  if (!isset($config['arg1'])){
    $config['arg1'] = $type;
  }

 start_buffer();
 include('template/user_back_link.php');
 return get_buffer();
}
add_listener('user_back_link','user_back_link');


function user_table_tools($tag,$config){

	start_buffer();
	include('template/user_table_tools.php');
	return get_buffer();

}
add_listener('user_table_tools','user_table_tools');


