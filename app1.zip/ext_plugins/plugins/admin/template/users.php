<div class="col-xs-12">
	<h3>Users (<?php echo session('entity_type'); ?>) /<?php echo __filter('company_badge',$company_id); ?></h3>
</div>

<?php 
 // print_r($_SERVER);


$e = array('a'=>'b','c'=>'d');
$f = array('c'=>'d','a'=>'b');

// echo json_encode($e);
// echo '<br />';
// echo json_encode($f);

?>

<div class="col-xs-12" align="right">
<!-- 	<a href="<?php echo base_url(); ?>admin/add_user" class="btn btn-primary"> + Add User</a>
 --></div>

<div class="col-xs-12">
	<?php 
      __filter('log_message');
	?>
</div>


<div class="col-xs-12">
	<table class="table">
		<tr>
			<th>
				E-mail
			</th>
			<th>
				Phone
			</th>
			<th>
				Status
			</th>
		</tr>
		<?php 
         foreach ($users as $k=>$v){

         	?>
            
            <tr>
            	<td>
            		<?php echo $v->email; ?>
            	</td>


            	<td>
            		<?php echo $v->phone; ?>
            	</td>




            	<td>
            		<?php echo $v->status; ?>
            	</td>

            	<td>

<?php 
 if (empty($cid)){
?>

<a href="<?php echo base_url(); ?>actions/launch/admin/enable/<?php echo $v->id; ?>">Enable</a>&nbsp;|&nbsp;<a href="<?php echo base_url(); ?>actions/launch/admin/disable/<?php echo $v->id; ?>">Disable</a>

            		<a href="<?php echo base_url(); ?>admin/edit/<?php echo $v->id; ?>" class="btn btn-success">Edit</a>
<?php 
 }
?>                  
            	</td>
            </tr>

         	<?php 

         }
		?>
	</table>
</div>