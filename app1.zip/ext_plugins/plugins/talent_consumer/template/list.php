<div class="col-xs-12">
	<h3>Talents Under <?php echo __filter('consumer_map_field',$consumer_id,'email') ; ?></h3>
</div>

<?php 
 // print_r($_SERVER);
?>

<div class="col-xs-12" align="right">
<!-- 	<a href="<?php echo base_url(); ?>admin/add_user" class="btn btn-primary"> + Add User</a>
 --></div>

<div class="col-xs-12">
	<?php 
      __filter('log_message');
	?>
</div>


<div class="col-xs-12">
	<table class="table">
		<tr>
			<th>
				Surname
			</th>
			<th>
				First Name
			</th>
         <th>
            Last Name
         </th>
         <th>
            Gender
         </th>         
         <th>
            Phone
         </th>
         <th>
            E-mail
         </th>
         <th>
           BVN
         </th>
         <th>
           Account-Number
         </th>
         <th>
           Gender
         </th>
		</tr>
		<?php 
         foreach ($result['record'] as $k=>$v){

         	?>
            
     <tr>

      <td>
        <?php echo __filter('talent_map_field',$v->talent_id,'surname'); ?>
      </td>
      <td>
        <?php echo __filter('talent_map_field',$v->talent_id,'first_name'); ?>
      </td>
         <td>
            <?php echo __filter('talent_map_field',$v->talent_id,'last_name'); ?>
         </td>
         <td>
            <?php echo __filter('talent_map_field',$v->talent_id,'gender'); ?>
         </td>         
         <td>
            <?php echo __filter('talent_map_field',$v->talent_id,'phone'); ?>
         </td>
         <td>
            <?php echo __filter('talent_map_field',$v->talent_id,'email'); ?>
         </td>
         <td>
           <?php echo __filter('talent_map_field',$v->talent_id,'bvn'); ?>
         </td>
         <td>
           <?php echo __filter('talent_map_field',$v->talent_id,'account_number'); ?>
         </td>
         <td>
           <?php echo __filter('talent_map_field',$v->talent_id,'gender'); ?>
         </td>

            </tr>

         	<?php 

         }
		?>
	</table>
</div>

<div class="col-xs-12">
   <?php 
     if (isset($result['pagination']['firstpage'])){
   ?>
   <a href="?page=<?php echo $result['pagination']['firstpage']; ?>" class="btn btn-default">First</a>
   <?php   
     }
   ?>

   <?php 
     if (isset($result['pagination']['prevpage'])){
   ?>
   <a href="?page=<?php echo $result['pagination']['prevpage']; ?>" class="btn btn-default">Prev</a>
   <?php   
     }
   ?>



   <?php 
     if (isset($result['pagination']['nextpage'])){
   ?>
   <a href="?page=<?php echo $result['pagination']['nextpage']; ?>" class="btn btn-default">Next</a>
   <?php   
     }
   ?>


      <?php 
     if (isset($result['pagination']['lastpage'])){
   ?>
   <a href="?page=<?php echo $result['pagination']['lastpage']; ?>" class="btn btn-default">Last</a>
   <?php   
     }
   ?>   
</div>
