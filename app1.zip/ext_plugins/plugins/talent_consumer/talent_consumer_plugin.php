<?php 

require_once('usecases.php');

function nav_talent_consumer_list($consumer_id=''){
  
  start_buffer();

  $result = __action('record_management',array(
   "table"=>"talent_consumer",
   "limit"=>30,
   "criteria"=>array("consumer_id"=>$consumer_id),
   "sort"=>array("id","desc")
  ));

  include('template/list.php');

  return __action('nav_admin_panel',get_buffer());


}
add_listener('nav_talent_consumer_list','nav_talent_consumer_list');


