<?php 

function uc_talent_consumer_register(){
 
 $post_data = request('post_data');//should also contain consumer_id
 $post_data['date_created'] = date('Y-m-d h:i:s');

 $criteria = array(
  "email"=>$post_data['email'],
  "phone"=>$post_data['phone'],
  "bvn"=>$post_data['bvn']
 );

 $resp = __action('entity_get_where','talent',$criteria);

 if (count($resp) > 0){
   $resp = $resp[0];
   $talent_id = $resp->id;
   $post_data['talent_id'] = $talent_id;
   $consumer_id = $post_data['consumer_id'];

	 // $talent_id = $post_data['talent_id'];

	 __action('launch_usecase',array('talent','spam_count',$talent_id));
	 $spam_count = response('spam_count');

	 if ($spam_count > 0){
	  //
	 }else{

	 	unset($post_data['bvn']);
	 	unset($post_data['email']);
	 	unset($post_data['phone']);

	 	$check = __action('entity_get_where','talent_consumer',array(
          'consumer_id'=>$consumer_id,
          'talent_id'=>$talent_id
	 	));

	 	if (count($check) > 0){
            log_error('Talent already assigned!');
	 	}else{

			 __action('entity_create','talent_consumer',$post_data);
			 log_success('Talent Assigned successfully'); 	


	 	}


	 }

 }else{
   log_error('Record mismatch!');
 }



}
add_listener('uc_talent_consumer_register','uc_talent_consumer_register');


function uc_vacate_talent(){
 
 $post_data = request('post_data');

 if (isset($post_data['consumer_id'])){
  if (isset($post_data['talent_id'])){
  	
  	$post_data['status'] = 0;
  	$post_data['date_terminated'] = date('Y-m-d h:i:s');


  	__action('entity_where','id',$post_data['id']);
  	__action('entity_update','talent_consumer',$post_data);
  	log_success('Talent successfully vacated.');
    
  }else{
  	 log_error('Talent not detected!');
  }
 }else{
 	log_error('Account not detected!');
 }

}
add_listener('uc_vacate_talent','uc_vacate_talent');


function uc_active_sub_talents(){
 
 $post_data = request('post_data');	

 $consumer_id = $post_data['consumer_id'];
  
 $resp = __action('entity_get_where','talent_consumer',array("consumer_id"=>$consumer_id,"status"=>"1")); 

 foreach ($resp as $k=>$v){

 	$resp[$k]->talent_name = __action('talent_map_field',$v->talent_id,'surname') . ' , ' . __action('talent_map_field',$v->talent_id,'first_name');

 }

 response('data',$resp);
}
add_listener('uc_active_sub_talents','uc_active_sub_talents');

