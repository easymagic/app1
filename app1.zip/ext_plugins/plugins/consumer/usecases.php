<?php 

function uc_consumer_register(){
  
  $post_data = request('post_data');

  $email = $post_data['email'];
  
  $password = $post_data['password'];
  $password2 = $post_data['password2'];

  $post_data['date_created'] = date('Y-m-d h:i:s');

  $check = __action('entity_get_where','consumer',array("email"=>$email));

  if (count($check) > 0){
   log_error('An account with this E-mail already exists!');
  }else{

    if ($password == $password2 && !empty($password2)){
       unset($post_data['password2']);
       __action('entity_create','consumer',$post_data);
       log_success('Registration confirmed.');        
    }else{
      log_error('Invalid password!');
    }

  }

}
add_listener('uc_consumer_register','uc_consumer_register');


function uc_consumer_login(){

 $post_data = request('post_data'); 
 
 $email = $post_data['email'];
 $password = $post_data['password'];

 $criteria = array();
 $criteria['email'] = $email;
 $criteria['password'] = $password;


 $account = __action('entity_get_where','consumer',$criteria);

 if (count($account) > 0){
   response('auth_data',$account[0]);
   log_success('Login Confirmed');
 }else{
   log_error('Invalid login!');
 }

}
add_listener('uc_consumer_login','uc_consumer_login');


function uc_consumer_list(){
 
 $resp = __action('entity_get','consumer');

 response('data',$resp);

}
add_listener('uc_consumer_list','uc_consumer_list');