<div class="col-xs-12">
	<h3>Consumers / <?php echo ucfirst($type); ?> - List</h3>
</div>

<?php 
 // print_r($_SERVER);
?>

<div class="col-xs-12" align="right">
<!-- 	<a href="<?php echo base_url(); ?>admin/add_user" class="btn btn-primary"> + Add User</a>
 --></div>

<div class="col-xs-12">
	<?php 
      __filter('log_message');
	?>
</div>


<div class="col-xs-12">
	<table class="table">
		<tr>
         <?php 
           if ($type == 'company'){
         ?>
         <th>
            Name
         </th>         
        <?php 
         }else{
        ?> 
			<th>
				Surname
			</th>
			<th>
				First Name
			</th>
         <th>
            Last Name
         </th>
         <th>
            Gender
         </th>         
         <?php 
          }
         ?>
         <th>
            Phone
         </th>
         <th>
            E-mail
         </th>
		</tr>
		<?php 
         foreach ($result['record'] as $k=>$v){

         	?>
            
            <tr>

         <?php 
           if ($type == 'company'){
         ?>
         <td>
            <?php echo $v->name ?>
         </td>         
        <?php 
         }else{
        ?> 
         <td>
            <?php echo $v->surname; ?>
         </td>
         <td>
            <?php echo $v->first_name; ?>
         </td>
         <td>
            <?php echo $v->last_name; ?>
         </td>
         <td>
            <?php echo $v->gender; ?>
         </td>         
         <?php 
          }
         ?>
         <td>
            <?php echo $v->phone; ?>
         </td>
         <td>
            <?php echo $v->email ?>
         </td>


            	<td>

                  <a href="<?php echo base_url(); ?>talent/consumer_list/<?php echo $v->id; ?>" class="btn btn-info">View Talents</a>

            	</td>

            </tr>

         	<?php 

         }
		?>
	</table>
</div>

<div class="col-xs-12">
   <?php 
     if (isset($result['pagination']['firstpage'])){
   ?>
   <a href="?page=<?php echo $result['pagination']['firstpage']; ?>" class="btn btn-default">First</a>
   <?php   
     }
   ?>

   <?php 
     if (isset($result['pagination']['prevpage'])){
   ?>
   <a href="?page=<?php echo $result['pagination']['prevpage']; ?>" class="btn btn-default">Prev</a>
   <?php   
     }
   ?>



   <?php 
     if (isset($result['pagination']['nextpage'])){
   ?>
   <a href="?page=<?php echo $result['pagination']['nextpage']; ?>" class="btn btn-default">Next</a>
   <?php   
     }
   ?>


      <?php 
     if (isset($result['pagination']['lastpage'])){
   ?>
   <a href="?page=<?php echo $result['pagination']['lastpage']; ?>" class="btn btn-default">Last</a>
   <?php   
     }
   ?>   
</div>
