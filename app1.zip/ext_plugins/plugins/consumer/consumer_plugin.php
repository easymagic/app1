<?php 

require_once('usecases.php');


function nav_consumer_list($type=''){
  
  $result = __action('record_management',array(
   "table"=>"consumer",
   "limit"=>30,
   "sort"=>array("id","desc"),
   "criteria"=>array(
     "account_type"=>$type
   )
  ));

  start_buffer();

  include('template/consumers.php');

  return __action('nav_admin_panel',get_buffer());

}
add_listener('nav_consumer_list','nav_consumer_list');


function nav_consumer_view(){
  return __action('nav_consumer_list','consumer');
}
add_listener('nav_consumer_view','nav_consumer_view');


function nav_consumer_company(){
  return __action('nav_consumer_list','company');
}
add_listener('nav_consumer_company','nav_consumer_company');


function consumer_map_field($consumer_id,$field){
  
  $resp = __action('entity_get_where','consumer',array("id"=>$consumer_id));
  return $resp[0]->$field;

}
add_listener('consumer_map_field','consumer_map_field');

