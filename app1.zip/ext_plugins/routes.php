<?php 

 ///ext_plugins $routes

 $routes['default_route_model'] = 'app';


 $routes['very-cool'] = 'app/index';


